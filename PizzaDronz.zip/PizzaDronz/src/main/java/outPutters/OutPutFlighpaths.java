package outPutters;

import java.io.File;
import aStarSolver.Move;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import uk.ac.ed.inf.ilp.data.Order;

import java.io.IOException;
import java.time.LocalDate;

public class OutPutFlighpaths {
    public static void generateFlighpaths(String date, Move[] moves){

        try {

            //Create resultsfiles folder in parent directory of the project
            String currentDirectoryPath = System.getProperty("user.dir");
            File currentDirectory = new File(currentDirectoryPath).getParentFile();
            File resultsFilesDirectory = new File(currentDirectory, "resultsFiles");

            if (!resultsFilesDirectory.exists()) {
                if (resultsFilesDirectory.mkdir()) {
                    System.out.println("Created 'resultsFiles' directory.");
                } else {
                    System.err.println("Failed to create 'resultsFiles' directory.");
                }
            }
            else{
                System.out.println("'resultsFiles' directory already exists");
            }

            //Write flightpaths to file
            ObjectMapper objectMapper = new ObjectMapper();

            File outputFile = new File(resultsFilesDirectory.getAbsolutePath(), "flightpath-" + date + ".json");

            objectMapper.writeValue(outputFile, moves);

        } catch (IOException e){
            e.printStackTrace();
        }


    }
}

package restHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.net.URL;

//Basereciever class that all other recievers inherit from.
public class BaseReceiver {
    //Creates an object mapper object and checks baseurl valid.s
    public static ObjectMapper baseReceiver(String baseurl){
        String url =baseurl;

        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());

        try {
            var temp = new URL(url);
        } catch (Exception x) {
            System.err.println("The URL is invalid: " + x);
            System.exit(2);
        }

        return mapper;
    }
}

package restHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import uk.ac.ed.inf.ilp.data.NamedRegion;

import java.io.IOException;
import java.net.URL;

public class NoFlyReceiver extends BaseReceiver {
    public NamedRegion[] coordReciever(String url){
        //recieves noflyzone data from the rest server
        ObjectMapper mapper = baseReceiver(url);

        try {
            NamedRegion[] coords = mapper.readValue(new URL(url + "/noFlyZones"), NamedRegion[].class);
            return coords;
        } catch (IOException e) {
            //throw new RuntimeException(e);
            System.out.println("Invalid URL");
            System.exit(2);
            throw new RuntimeException(e);
        }
    }

    //just used for checking it works
    public static void main(String[] args){
        NoFlyReceiver coordreciever = new NoFlyReceiver();
        NamedRegion[] coords = coordreciever.coordReciever("https://ilp-rest.azurewebsites.net");
        System.out.println(coords[0]);
        System.out.println(coords[0].vertices()[0]);
    }
}

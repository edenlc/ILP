package restHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import uk.ac.ed.inf.ilp.data.Order;


import java.io.IOException;
import java.net.URL;

public class OrderReceiver extends BaseReceiver {
    public Order[] orderReceiver(String date, String url){
        //used to receive the orders from the rest server
        ObjectMapper mapper = baseReceiver(url);

        try {
            Order[] orders = mapper.readValue(new URL(url + "/orders/" + date), Order[].class);
            return orders;
        } catch (IOException e) {
            System.out.println("Invalid URL and/or date");
            System.exit(2);
            throw new RuntimeException(e);
        }


    }
    //just used for some basic testing
    public static void main(String[] args){
        OrderReceiver reciever = new OrderReceiver();
        Order[] rs = reciever.orderReceiver("2023-10-20", "https://ilp-rest.azurewebsites.net");

        System.out.println(rs[0].getOrderNo());
    }
}

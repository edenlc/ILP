package uk.ac.ed.inf;

/**
 * Hello world!
 *
 */
public class App {
    LngLatHandler lnglattester = new LngLatHandler();

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
    //LngLatHandler lnglattester = new LngLatHandler();
}
